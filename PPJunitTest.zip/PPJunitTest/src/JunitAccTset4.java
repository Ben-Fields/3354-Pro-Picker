import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class JunitAccTset4 {

	@Test
	public void test() throws IOException {
		
		//False: Invalid account credentials(email is already registered from first test case)
		AccountTest test = new AccountTest();
		boolean result = test.createAccount("Erik", "Van Slyke", "eriktestemail@gmail.com");
		assertEquals(false, result);
		
	}

}
