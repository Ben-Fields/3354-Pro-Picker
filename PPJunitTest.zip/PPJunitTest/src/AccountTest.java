import java.io.*;
import java.util.Scanner;

public class AccountTest {

	private int ID;
	private String firstName;
	private String lastName;
	private String emailAddress;
	
	public boolean createAccount(String firstName, String lastName, String emailAddress) throws IOException {
			
		this.ID = createID();		//create ID and call setID to save it to global variable
		if(setFirstName(firstName) && setLastName(lastName) && setEmailAddress(emailAddress)) {	//check if credentials that are passed are valid
			saveID(this.ID);				//add ID to IDList.dat to save the users unique ID
			saveEmail(this.emailAddress);	//add email to EmailList.dat to save the users email so no duplicate accounts can be created from one account
			return true;					//account successfully created :)
		}
		return false;				//account creation unsuccessful :(
		
	}
	
	private static int createID() throws IOException {
		
		int ID = (int)Math.floor(Math.random() * Math.pow(2, 31));	//generate random ID between 0 and 2147483648
		while(checkIDExists(ID)) {									//check if ID exists in IDList.dat and loop until unique ID is created
			ID = (int)Math.floor(Math.random() * Math.pow(2, 31));	//generate new random ID
		}
		return ID;
		
	}
	
	private static boolean checkIDExists(int ID) throws FileNotFoundException {
		
		Scanner sc = new Scanner(new File("src/IDList.dat"));
		while(sc.hasNextInt())			//loop until end of file
			if(sc.nextInt() == ID) {	//if ID is found in file return true that IDExists
				sc.close();
				return true;
			}
		sc.close();
		return false;
		
	}
	
	private static void saveID(int ID) throws IOException {
	
		BufferedWriter bw = new BufferedWriter(new FileWriter("src/IDList.dat", true));
		bw.append("\n" + ID);	//append ID to file
		bw.close();
		
	}
	
	public boolean setFirstName(String firstName) { //keep public so user can change name later
		
		if(!firstName.contains(" ")) {
			this.firstName = firstName;
			return true;
		}
		return false;
		
	}
	
	public boolean setLastName(String lastName) {	//keep public so user can change name later
		
		lastName = lastName.substring(0,1).toUpperCase() + lastName.substring(1, lastName.length()).toLowerCase();	//format last name(first letter uppercase rest lowercase)
		this.lastName = lastName;
		return true;
		
	}
	
	public boolean setEmailAddress(String emailAddress) throws FileNotFoundException {
		
		int atIdx = emailAddress.indexOf("@");	//find idx where domain begins
		if(atIdx > -1 && emailAddress.indexOf(".") > atIdx && atIdx <= 64) {  //general rules for a valid email address
			if(checkEmailExists(emailAddress)) {	//check if email exists and return false if it does exist
				return false;
			} else {
				this.emailAddress = emailAddress;
				return true;
			}
		}
		return false;
		
	}
	
	private static boolean checkEmailExists(String emailAddress) throws FileNotFoundException {
		
		Scanner sc = new Scanner(new File("src/EmailList.dat"));
		while(sc.hasNext())	//loops until end of file
			if(sc.next().equalsIgnoreCase(emailAddress)) {	//compare each address in file to passed email ignoring case; return true if email is found
				sc.close();
				return true;
			}
		sc.close();
		return false;
		
	}
	
	private static void saveEmail(String emailAddress) throws IOException {
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("src/EmailList.dat", true));
		bw.append("\n" + emailAddress);	//append email to end of list to check duplicates in future account creation
		bw.close();
		
	}
	
}
