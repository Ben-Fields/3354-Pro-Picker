//####################################################################################
//# 																				 #
//# 		IMPORTANT CLEAR IDList.dat AND EmailList.dat BEFORE RUNNING TEST		 #
//# 																				 #
//####################################################################################

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Test;

public class JunitAccTest {

	@Test
	public void test() throws IOException {
		
		/*clear ID and email files to begin testing
		BufferedWriter w = new BufferedWriter(new FileWriter("src/IDList.dat", true));
		BufferedWriter w1 = new BufferedWriter(new FileWriter("src/EmailList.dat", true));
		w.write("");
		w.flush();
		w1.write("");
		w1.flush();
		w.close();
		w1.close();*/
		
		//test to create first account; True: account credentials are valid
		AccountTest test = new AccountTest();
		boolean result = test.createAccount("Erik", "Van Slyke", "eriktestemail@gmail.com");
		assertEquals(true, result);
		
	}

}
