import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class JunitAccTest2 {

	@Test
	public void test() throws IOException {
		
		//False: Invalid account credentials(Email does not contain '@' character)
		AccountTest test = new AccountTest();
		boolean result = test.createAccount("John", "Doe", "JohnDDoegmail.com");
		assertEquals(false, result);
		
	}

}
