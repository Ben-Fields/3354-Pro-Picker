import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class JunitAccTest1 {

	@Test
	public void test() throws IOException {
		
		//False: Invalid account credentials(First name has a space)
		AccountTest test = new AccountTest();
		boolean result = test.createAccount("John D", "Doe", "JohnDDoe@gmail.com");
		assertEquals(false, result);
		
	}

}
