import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class JunitAccTest3 {

	@Test
	public void test() throws IOException {
		AccountTest test = new AccountTest();
		boolean result = test.createAccount("John", "Doe", "JohnDDoe@gmailcom");
		assertEquals(false, result);
	}

}
