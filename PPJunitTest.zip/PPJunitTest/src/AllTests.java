//####################################################################################
//# 																				 #
//# 		IMPORTANT CLEAR IDList.dat AND EmailList.dat BEFORE RUNNING TEST		 #
//# 																				 #
//####################################################################################

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ JunitAccTest.class, JunitAccTest1.class, JunitAccTest2.class, JunitAccTest3.class,
		JunitAccTset4.class })
public class AllTests {
	
}
